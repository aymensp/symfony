$(function () {

    $("#jsGrid").jsGrid({
        height: "100%",
        width: "100%",
        filtering: false,
        editing: true,
        inserting: true,
        sorting: true,
        paging: true,
        autoload: true,
        pageSize: 15,
        pageButtonCount: 5,
        deleteConfirm: "Do you really want to delete this game?",
        controller: db_games,
        fields: [
            {name: "Id", type: "text"},
            {name: "Home Team", type: "text"},
            {name: "Away Team", type: "text"},
            {name: "Result", type: "text"},
            {name: "Date", type: "text", width: 110},
            {name: "Summary", type: "text"},
            {
                name: "Summary Photo", itemTemplate: function (value) {
                    return $("<img>").attr("src", value);
                }, type: "text"
            },
            {name: "Highlights", type: "text"},
            {name: "Referee", type: "text", width: 80},
            {name: "Squads", type: "text", width: 80},
            {name: "Stadium", type: "text", width: 80},
            {type: "control"}
        ]
    });

});