(function () {

    var db_games = {

        loadData: function (filter) {
            return $.grep(this.games, function (client) {
                return (!filter.id || client.id.indexOf(filter.id) > -1)
                return (!filter.hometeam || client.hometeam.indexOf(filter.hometeam) > -1)
            });
        },

        insertItem: function (insertingClient) {
            this.games.push(insertingClient);
        },

        updateItem: function (updatingClient) {
        },

        deleteItem: function (deletingClient) {
            var clientIndex = $.inArray(deletingClient, this.games);
            this.games.splice(clientIndex, 1);
        }

    };

    db_games.games = [];
    for (var i = 0; i < data_games.length; i++) {
        console.log(data_games[i].date);
        db_games.games.push({
            "Id": data_games[i].id,
            "Home Team": data_games[i].hometeam.name,
            "Away Team": data_games[i].awayteam.name,
            "Result": data_games[i].result,
            "Date": new Date(data_games[i].date).toLocaleDateString("fr-FR"),
            "Summary": data_games[i].summary,
            "Summary Photo": data_games[i].summaryphoto,
            "Highlights": data_games[i].highlights,
            "Referee": data_games[i].referee,
            "Squads": data_games[i].squads,
            "Stadium": data_games[i].stadium.name

        });
    }
    window.db_games= db_games;

}());